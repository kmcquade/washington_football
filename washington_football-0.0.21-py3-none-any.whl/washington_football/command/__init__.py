from washington_football.command import suck
